#include<stdio.h>
#include<unistd.h>
int main() {
   char hostname[20];
   //gethostname is a predefined function which returns the hostname
   gethostname(hostname,20);
   printf("%s",hostname);
}