#include <math.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
extern float f1(float x, int intensity);
extern float f2(float x, int intensity);
extern float f3(float x, int intensity);
extern float f4(float x, int intensity);
int main (int argc, char* argv[])
{
 if (argc < 6)
  {
    fprintf(stderr, "usage: %s <functionid> <a> <b> <n> <intensity>", argv[0]);
    return -1;
  }
  else
  {
    int functionid,n,a,b,intensity;
    float x,y =0;
    functionid= atoi(argv[1]);
    a= atoi(argv[2]);
    b= atoi(argv[3]);
    n=atoi(argv[4]);
    intensity=atoi(argv[5]);
    float sum=0,numericintegration;
    clock_t start,end
    double cpu_time_used;
    start=clock();
    for(int i=1;i<n;i++)
    {
        x=((float)a+((float)i+0.5)*(((float)b-(float)a)/(float)n));
        switch(functionid)
        {
            case 1: y +=f1(x,intensity);
            break;
            case 2: y +=f2(x,intensity);
            break;
            case 3: y +=f3(x,intensity);
            break;
            case 4: y +=f4(x,intensity);
            break;
        }
    }
    numericintegration= y*(((float)b-(float)a)/(float)n);
    end=clock()
    cpu_time_used=((double)(end-start))/CLOCKS_PER_SEC;
    fprintf(stdout,"%f",numericintegration);
    fprintf(stderr,"%f",cpu_time_used);
  }
  return 0;
}
