#!/bin/sh
qsub -d  $(pwd) queue_job.pbs
