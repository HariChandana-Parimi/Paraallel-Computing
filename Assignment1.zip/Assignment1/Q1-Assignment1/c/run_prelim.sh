
make prelim
./prelim > preliminary_answer
